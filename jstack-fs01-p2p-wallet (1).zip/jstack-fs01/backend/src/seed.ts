import 'dotenv/config';import mongoose from 'mongoose';import bcrypt from 'bcryptjs';import {User} from './models';
async function main(){if(!process.env.MONGODB_URI)throw Error('MONGODB_URI required');await mongoose.connect(process.env.MONGODB_URI);const hash=await bcrypt.hash('password123',10);
for(const [name,email] of [['Asha Sharma','asha@example.com'],['Rohan Verma','rohan@example.com'],['Meera Patel','meera@example.com']])await User.updateOne({email},{$setOnInsert:{name,email,passwordHash:hash,balance:1000000}},{upsert:true});
console.log('Seeded 3 demo users (existing balances unchanged)');await mongoose.disconnect()}
main().catch(e=>{console.error(e);process.exit(1)});
