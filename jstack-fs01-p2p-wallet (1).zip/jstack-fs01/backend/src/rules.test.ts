import {it,expect} from 'vitest';import {validate,fingerprint} from './rules';
const a='aaaaaaaaaaaaaaaaaaaaaaaa',b='bbbbbbbbbbbbbbbbbbbbbbbb';
it('valid amount',()=>expect(validate(a,b,50000)).toBeNull());
it('rejects self transfer',()=>expect(validate(a,a,50000)).toBeTruthy());
it('rejects fractional paise',()=>expect(validate(a,b,100.5)).toBeTruthy());
it('rejects below min',()=>expect(validate(a,b,99)).toBeTruthy());
it('rejects above max',()=>expect(validate(a,b,5000001)).toBeTruthy());
it('same payload has same fingerprint',()=>expect(fingerprint(b,500)).toBe(fingerprint(b,500)));
it('different payload has different fingerprint',()=>expect(fingerprint(b,500)).not.toBe(fingerprint(b,501)));
