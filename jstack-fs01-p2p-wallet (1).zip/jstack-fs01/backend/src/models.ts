import mongoose,{Schema,Types} from 'mongoose';
export const User=mongoose.model('User',new Schema({name:{type:String,required:true},email:{type:String,unique:true,required:true},passwordHash:{type:String,required:true},balance:{type:Number,required:true,min:0,default:1000000}},{timestamps:true}));
const transactionSchema=new Schema({fromUserId:{type:Types.ObjectId,ref:'User',required:true},toUserId:{type:Types.ObjectId,ref:'User',required:true},amount:{type:Number,required:true,min:100,max:5000000}},{timestamps:true});
transactionSchema.index({fromUserId:1,createdAt:-1});transactionSchema.index({toUserId:1,createdAt:-1});
export const Transaction=mongoose.model('Transaction',transactionSchema);
const keySchema=new Schema({senderId:{type:Types.ObjectId,required:true},key:{type:String,required:true},fingerprint:{type:String,required:true},result:{type:Schema.Types.Mixed,required:true}},{timestamps:true});
keySchema.index({senderId:1,key:1},{unique:true});
export const TransferKey=mongoose.model('TransferKey',keySchema);
