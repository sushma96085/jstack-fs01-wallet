import {createHash} from 'node:crypto';
export function validate(sender:string,receiver:unknown,amount:unknown):string|null{
 if(typeof receiver!=='string'||!/^[0-9a-f]{24}$/i.test(receiver))return 'Valid receiver required';
 if(receiver===sender)return 'Cannot send money to yourself';
 if(typeof amount!=='number'||!Number.isSafeInteger(amount)||amount<100||amount>5000000)return 'Amount must be integer paise between ₹1 and ₹50,000';
 return null;
}
export function fingerprint(receiver:string,amount:number){return createHash('sha256').update(`${receiver}:${amount}`).digest('hex')}
