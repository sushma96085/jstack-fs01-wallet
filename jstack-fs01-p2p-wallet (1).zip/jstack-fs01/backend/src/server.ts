import 'dotenv/config';
import express,{Request,Response,NextFunction} from 'express';import cors from 'cors';import jwt from 'jsonwebtoken';import bcrypt from 'bcryptjs';import mongoose,{Types} from 'mongoose';
import {User,Transaction,TransferKey} from './models';import {validate,fingerprint} from './rules';
const app=express();app.use(cors({origin:process.env.FRONTEND_ORIGIN||'http://localhost:5173'}));app.use(express.json());
type AuthReq=Request&{userId?:string};
const secret=()=>{if(!process.env.JWT_SECRET)throw Error('JWT_SECRET required');return process.env.JWT_SECRET};
function auth(req:AuthReq,res:Response,next:NextFunction){try{const token=req.header('authorization')?.replace(/^Bearer /i,'');if(!token)return res.status(401).json({error:'Login required'});const payload=jwt.verify(token,secret()) as jwt.JwtPayload;if(!payload.sub||!Types.ObjectId.isValid(payload.sub))throw Error('Bad token');req.userId=payload.sub;next()}catch{return res.status(401).json({error:'Invalid or expired token'})}}
app.get('/api/health',(_req,res)=>res.json({ok:true}));
app.post('/api/auth/login',async(req,res)=>{try{const user=await User.findOne({email:String(req.body?.email||'').toLowerCase().trim()});if(!user||!await bcrypt.compare(String(req.body?.password||''),String(user.passwordHash)))return res.status(401).json({error:'Invalid credentials'});return res.json({token:jwt.sign({sub:user.id},secret(),{expiresIn:'2h'}),user:{id:user.id,name:user.name,email:user.email}})}catch(e){console.error(e);return res.status(500).json({error:'Login unavailable'})}});
app.get('/api/users',auth,async(req:AuthReq,res)=>{const rows=await User.find({_id:{$ne:req.userId}}).select('name email').lean();res.json(rows.map(x=>({id:String(x._id),name:x.name,email:x.email})))});
app.get('/api/wallet',auth,async(req:AuthReq,res)=>{const u=await User.findById(req.userId);if(!u)return res.status(404).json({error:'Wallet not found'});return res.json({balance:u.balance,currency:'INR',unit:'paise'})});
app.get('/api/transactions',auth,async(req:AuthReq,res)=>{const id=new Types.ObjectId(req.userId);const rows=await Transaction.find({$or:[{fromUserId:id},{toUserId:id}]}).sort({createdAt:-1,_id:-1}).limit(100).populate('fromUserId','name email').populate('toUserId','name email').lean();res.json(rows.map((x:any)=>({id:String(x._id),from:{id:String(x.fromUserId._id),name:x.fromUserId.name},to:{id:String(x.toUserId._id),name:x.toUserId.name},amount:x.amount,createdAt:x.createdAt})))});
app.post('/api/wallet/transfer',auth,async(req:AuthReq,res)=>{
 const key=req.header('Idempotency-Key');if(!key||!key.trim())return res.status(400).json({error:'Idempotency-Key header required'});if(key.length>200)return res.status(400).json({error:'Idempotency-Key too long'});
 const {toUserId,amount}=req.body||{};const hash=typeof toUserId==='string'&&typeof amount==='number'?fingerprint(toUserId,amount):'';
 // Check existing key BEFORE validation, to replay original result even if user retries.
 const previous=await TransferKey.findOne({senderId:req.userId,key}).lean();if(previous)return previous.fingerprint===hash?res.status(201).json(previous.result):res.status(409).json({error:'Key already used for a different transfer'});
 const problem=validate(req.userId!,toUserId,amount);if(problem)return res.status(400).json({error:problem});
 const session=await mongoose.startSession();let result:any;
 try{
  await session.withTransaction(async()=>{
   const existing=await TransferKey.findOne({senderId:req.userId,key}).session(session);
   if(existing){if(existing.fingerprint!==hash)throw Object.assign(Error('Key already used for a different transfer'),{status:409});result=existing.result;return}
   const receiver=await User.findById(toUserId).session(session);if(!receiver)throw Object.assign(Error('Receiver not found'),{status:404});
   const sender=await User.findOneAndUpdate({_id:req.userId,balance:{$gte:amount}},{$inc:{balance:-amount}},{new:true,session});
   if(!sender)throw Object.assign(Error('Insufficient balance'),{status:409});
   await User.updateOne({_id:toUserId},{$inc:{balance:amount}},{session});
   const [tx]=await Transaction.create([{fromUserId:req.userId,toUserId,amount}],{session});
   result={message:'Transfer successful',transactionId:String(tx._id),amount,balance:sender.balance};
   await TransferKey.create([{senderId:req.userId,key,fingerprint:hash,result}],{session});
  });
  return res.status(201).json(result);
 }catch(e:any){
  if(e?.code===11000){const replay=await TransferKey.findOne({senderId:req.userId,key}).lean();if(replay)return replay.fingerprint===hash?res.status(201).json(replay.result):res.status(409).json({error:'Key already used for a different transfer'});}
  if(e?.status)return res.status(e.status).json({error:e.message});
  console.error(e);return res.status(503).json({error:'Transfer uncertain; retry with the SAME Idempotency-Key'});
 }finally{await session.endSession()}
});
app.use((e:Error,_req:Request,res:Response,_next:NextFunction)=>{console.error(e);res.status(500).json({error:'Server error'})});
if(require.main===module){if(!process.env.MONGODB_URI||!process.env.JWT_SECRET)throw Error('Set MONGODB_URI and JWT_SECRET');mongoose.connect(process.env.MONGODB_URI).then(()=>app.listen(Number(process.env.PORT)||5000,()=>console.log('API ready on port '+(process.env.PORT||5000)))).catch(e=>{console.error(e);process.exit(1)})}
export default app;
