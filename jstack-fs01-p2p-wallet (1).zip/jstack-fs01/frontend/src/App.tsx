import {useCallback,useEffect,useState} from 'react';
import {Wallet,Send,ArrowUpRight,ArrowDownLeft,LogOut,History,ShieldCheck} from 'lucide-react';
type Person={id:string;name:string;email?:string};
type Tx={id:string;from:Person;to:Person;amount:number;createdAt:string};
const API=import.meta.env.VITE_API_URL||'http://localhost:5000/api';
const money=(n:number)=>new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR'}).format(n/100);
export default function App(){
const [token,setToken]=useState(localStorage.getItem('token')||'');
const [me,setMe]=useState<Person|null>(JSON.parse(localStorage.getItem('user')||'null'));
const [email,setEmail]=useState('asha@example.com'),[password,setPassword]=useState('password123');
const [balance,setBalance]=useState(0),[users,setUsers]=useState<Person[]>([]),[txs,setTxs]=useState<Tx[]>([]);
const [to,setTo]=useState(''),[amount,setAmount]=useState('500'),[busy,setBusy]=useState(false),[notice,setNotice]=useState('');
const [pending,setPending]=useState<{key:string;toUserId:string;amount:number}|null>(null);
const call=useCallback(async(path:string,opts:RequestInit={})=>{
const r=await fetch(API+path,{...opts,headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{}),...opts.headers}});
const d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||'Request failed');return d;
},[token]);
const refresh=useCallback(async()=>{const [w,u,t]=await Promise.all([call('/wallet'),call('/users'),call('/transactions')]);setBalance(w.balance);setUsers(u);setTxs(t);setTo(v=>v||u[0]?.id||'');},[call]);
useEffect(()=>{if(token)refresh().catch(e=>setNotice(e.message))},[token,refresh]);
async function login(e:React.FormEvent){e.preventDefault();setBusy(true);setNotice('');try{
const r=await fetch(API+'/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password})});
const d=await r.json();if(!r.ok)throw Error(d.error);localStorage.setItem('token',d.token);localStorage.setItem('user',JSON.stringify(d.user));setToken(d.token);setMe(d.user);
}catch(e){setNotice((e as Error).message)}finally{setBusy(false)}}
async function send(e:React.FormEvent){e.preventDefault();setBusy(true);setNotice('');const paise=Math.round(Number(amount)*100);
if(!Number.isFinite(Number(amount))||Math.abs(Number(amount)*100-paise)>1e-7){setNotice('Enter valid amount (maximum 2 decimal places)');setBusy(false);return}
const transfer=pending||{key:crypto.randomUUID(),toUserId:to,amount:paise};setPending(transfer);
try{await call('/wallet/transfer',{method:'POST',headers:{'Idempotency-Key':transfer.key},body:JSON.stringify({toUserId:transfer.toUserId,amount:transfer.amount})});
setPending(null);setNotice('Transfer successful!');await refresh();
}catch(e){setNotice((e as Error).message+' — Retry uses the same transfer key.')}finally{setBusy(false)}}
function logout(){localStorage.removeItem('token');localStorage.removeItem('user');setToken('');setMe(null);setPending(null);setNotice('')}
if(!token)return <main className="login-page"><form className="login-card" onSubmit={login}><div className="logo"><Wallet/></div><p className="eyebrow">JSTACK · ENGINEERING ASSESSMENT FS-01</p><h1>Money moves<br/><em>better together.</em></h1><p className="sub">Sign in to your demo wallet to get started.</p><label>Email<input type="email" value={email} onChange={e=>setEmail(e.target.value)}/></label><label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)}/></label><button disabled={busy}>Sign in <ArrowUpRight size={18}/></button>{notice&&<p className="notice">{notice}</p>}<small>Demo: asha@example.com / password123</small></form></main>;
return <div className="shell"><header><div className="brand"><span className="logo small"><Wallet size={20}/></span><div><strong>pocket</strong><small>PERSONAL WALLET</small></div></div><div className="account"><span className="avatar">{me?.name?.[0]}</span><strong>{me?.name}</strong><button className="logout" onClick={logout} title="Logout"><LogOut size={18}/></button></div></header>
<section className="hero"><p className="eyebrow">YOUR WALLET OVERVIEW</p><h1>Good to see you, {me?.name?.split(' ')[0]}.</h1><p>Send money to people you trust, in just a few clicks.</p><div className="hero-deco">₹</div></section>
{notice&&<div className="notice">{notice}</div>}
<div className="layout"><div className="column"><section className="card balance"><div className="section-top"><span>Available balance</span><Wallet size={20}/></div><h2>{money(balance)}</h2><p>Indian Rupee · INR</p><div className="balance-footer"><span>● Wallet active</span><span>FS-01</span></div></section>
<section className="card"><div className="heading"><span className="tile"><Send size={19}/></span><div><h3>Send money</h3><p>Instant wallet-to-wallet transfer</p></div></div>
<form onSubmit={send}><label>Send to<select value={to} onChange={e=>{setTo(e.target.value);setPending(null)}} required>{users.map(u=><option value={u.id} key={u.id}>{u.name} — {u.email}</option>)}</select></label><label>Amount (INR)<div className="amount"><span>₹</span><input type="number" step="0.01" min="1" max="50000" value={amount} onChange={e=>{setAmount(e.target.value);setPending(null)}} required/></div><small>Minimum ₹1 · Maximum ₹50,000</small></label><button disabled={busy||!to}>{busy?'Processing...':'Send money'} <ArrowUpRight size={18}/></button></form><p className="secure"><ShieldCheck size={15}/> Idempotent transfers protected by MongoDB</p></section></div>
<section className="card activity"><div className="heading"><span className="tile"><History size={19}/></span><div><h3>Recent activity</h3><p>Your sent and received transactions</p></div></div>{!txs.length?<div className="empty"><History size={32}/><h3>No transactions yet</h3><p>Your transfers will appear here.</p></div>:txs.map(t=>{const sent=t.from.id===me?.id;return <div className="tx" key={t.id}><span className={'tx-icon '+(sent?'out':'in')}>{sent?<ArrowUpRight size={20}/>:<ArrowDownLeft size={20}/>}</span><div className="tx-name"><strong>{sent?'Sent to '+t.to.name:'Received from '+t.from.name}</strong><small>{new Date(t.createdAt).toLocaleString('en-IN')}</small></div><strong className={sent?'negative':'positive'}>{sent?'−':'+'}{money(t.amount)}</strong></div>})}</section></div><footer>jStack · FS-01 P2P Wallet Transfer <span>All API amounts are in integer paise</span></footer></div>}
