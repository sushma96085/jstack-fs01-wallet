# FS-01 — P2P Wallet Transfer

**Assessment ID:** FS-01 · jStack Full Stack Engineer (MERN)

React + TypeScript frontend, Express + TypeScript backend, MongoDB Atlas database.

## Features
- Three seeded users with ₹10,000 (1,000,000 paise) each
- Demo JWT login (no registration)
- `GET /api/wallet` authenticated balance
- `POST /api/wallet/transfer` with `Idempotency-Key` required
- `GET /api/transactions` sent/received, newest first
- MongoDB transaction for atomic debit, credit, transaction and idempotency record
- Single-page React dashboard with transfer form, transaction history and error messages
- Transfer button disabled while request is running
- Failed/uncertain network retries use the same key until the request is resolved

## Prerequisites
Node.js 20+ and MongoDB Atlas (or a local replica set; standalone MongoDB cannot run transactions).

## Backend setup
```bash
cd backend
npm install
cp .env.example .env
```
Edit `backend/.env` with your actual Atlas password (URL-encode special characters), `JWT_SECRET`, and frontend origin.
Never commit `.env`.

```bash
npm run seed
npm run dev
```
Backend: `http://localhost:5000`

## Frontend setup
```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```
Frontend: `http://localhost:5173`

## Demo accounts
- `asha@example.com`
- `rohan@example.com`
- `meera@example.com`

Password for all: `password123` (demo only).

## API examples
`POST /api/auth/login`: `{"email":"asha@example.com","password":"password123"}`

Use returned JWT as `Authorization: Bearer <token>`.

`GET /api/wallet` returns `{"balance":1000000,"currency":"INR","unit":"paise"}` for a fresh wallet.

`POST /api/wallet/transfer` requires header `Idempotency-Key: <uuid>` and JSON body:
```json
{"toUserId":"<receiver-mongodb-id>","amount":50000}
```
All API amounts are **integer paise**, so 50000 means ₹500.
Limits: 100 to 5,000,000 paise (₹1 to ₹50,000). No self-transfers. Insufficient balance is rejected.

`GET /api/transactions` returns the authenticated user's sent/received transactions, newest first (up to 100).

## Idempotency and concurrent transfers
A unique compound index `(senderId, key)` ensures a logical request has one durable record. Successful transfers store the original response in the **same MongoDB transaction** as both wallet updates. Reusing a key with the same payload replays the original 201 result without moving funds. Reusing it with different data returns 409. Validation and insufficient-funds failures are not stored as successful transfers.

**Important:** If a request fails due to a network error or server uncertainty, retry with the *same* idempotency key, not a new one. The UI retains that key until the request succeeds or transfer details change. A new key represents a new transfer.

## Indexes
- `users.email` unique: login lookup and prevent duplicate demo users.
- `transferkeys(senderId, key)` unique: deduplicate transfers even during concurrent retries.
- `transactions(fromUserId, createdAt)` and `(toUserId, createdAt)`: accelerate newest-first history lookups for sent and received transfers.

## Tests
```bash
cd backend
npm test
```
Includes unit tests for amount bounds, integer paise, self-transfer and stable request fingerprints. End-to-end concurrent idempotency and rollback tests are not yet included.

## Theory answers

**1. What happens if the server crashes after debiting the sender but before crediting the receiver?**

The debit, credit, transaction record and idempotency record are inside one MongoDB transaction. If the server crashes before commit, uncommitted changes are rolled back, leaving balances unchanged. If commit succeeded but response was lost, retrying the same idempotency key returns the stored result without moving funds twice.

**2. What happens if two transfers from the same wallet run at the same moment?**

MongoDB transactions enforce write conflict handling. Both transfers conditionally debit the sender only when the current balance covers the amount. MongoDB transaction retries may rerun an operation after a transient conflict; a transfer that cannot be funded fails rather than overdrawing. The unique key index additionally protects concurrent duplicates.

## Assumptions
- All users share the same INR wallet currency.
- One transaction record appears in both sender and receiver history.
- Three users are seeded once; rerunning seed does not reset their balances.
- The login is intentionally demo-only, with a shared demo password.
- An Atlas replica set is required for atomic multi-document transactions.

## Incomplete tasks / improvements
- Integration tests against an ephemeral replica set for true duplicate concurrent requests and crash/rollback.
- Pagination, structured logs, rate limiting, stronger account security, and production deployment.
- Full production-grade uncertain-commit retry/reconciliation and transactional outbox.

## Submission
Create a GitHub repository, upload this folder, and reply to the assessment email with the repository link.
